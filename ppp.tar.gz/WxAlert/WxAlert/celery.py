# _*_ coding:utf-8 _*_
from __future__ import absolute_import

__author__ = 'weelin'
__date__ = '17/8/14下午10:24'
import os
import django
from celery import Celery
from django.conf import settings

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'WxAlert.settings')

app = Celery('WxAlert')

app.config_from_object('django.conf:settings')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)