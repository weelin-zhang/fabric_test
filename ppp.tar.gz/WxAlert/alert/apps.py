from django.apps import AppConfig


class AlertConfig(AppConfig):
    name = 'alert'
