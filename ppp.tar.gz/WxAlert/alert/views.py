# -*- coding: utf-8 -*-
import json
from django.shortcuts import render
from django.http import  HttpResponse
from django.views.generic import  View
# Create your views here.

from .models import AlertItems
from .tasks import send_msg


class IndexView(View):

    def get(self, request):
        return  HttpResponse('index')
    
    
class ReceiveMsgAndAlertView(View):
    
    def get(self, request):
        to_user = request.GET.get('to_user', '')
        alert_id = request.GET.get('alert_id', '')
        message = request.GET.get('msg', '')
        print to_user, alert_id, message

        alert_obj_l = AlertItems.objects.filter(name=alert_id)
        
        if not alert_obj_l:
            # 第一次报警
            alert_item = AlertItems()
            alert_item.name = alert_id           # 可以定义为唯一编号
            alert_item.desc = message
            try:
                alert_item.save()
            except:
                # 数据库写入出错,也要告警
                send_msg.delay(u'数据库写入出错', u'报警项信息写入数据库出错')
        
        else:
            print  u'不是第一次报警'
            # 不是第一次告警，更新信息(desc, has_alert)
            alert_obj = alert_obj_l[0]
            alert_obj.has_alert = False
            alert_obj.desc = message
            alert_obj.save()
            
            
                
        # 保存数据库成功后异步微信报警
        try:
            send_msg.delay(alert_id, message)
            #告警进入队列
            return HttpResponse(json.dumps({'status': u'ok'}))

        except Exception as e:
            #告警未进入队列
            print e
            return HttpResponse(json.dumps({'error': e}))

    # capture_url
    
class CeleryAlertSendVerifyView(View):
    
    def get(self, request, alert_id):
        if AlertItems.objects.filter(name=alert_id):

            print  u'有确认的celery'
            try:
                alert_obj = AlertItems.objects.get(name=alert_id)
                if not alert_obj.has_alert:
                    alert_obj.has_alert = True
                    alert_obj.save()
            except:
                # 数据库出问题
                pass
        
            return HttpResponse('verify success')
        else:
            return HttpResponse('no exists')
        
        
        
def capture(request, alert_id):
    if AlertItems.objects.filter(name=alert_id):
        alert_obj = AlertItems.objects.get(name=alert_id)
        if alert_obj.deal_people == u'未指派':
            alert_obj.deal_people = u'帅哥'
            alert_obj.save()
            return  HttpResponse(u'成功抢到{}'.format(alert_id))
        return HttpResponse(u'晚来一步<a href=http://www.baidu.com>aaa</a>')    # 可以嵌入网页