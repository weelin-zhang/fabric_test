# _*_ coding:utf-8 _*_

__author__ = 'weelin'
__date__ = '17/8/5下午10:52'

from .models import AlertItems
import xadmin
from xadmin import views


# 激活主题功能
class BaseSetting(object):
    enable_themes = True
    # use_bootswatch = True


# 设置主题
class GlobalSetting(object):
    site_title = u"慕学后台管理系统"
    site_footer = u'慕学在线网'
    menu_style = 'accordion'


xadmin.site.register(views.BaseAdminView, BaseSetting)

xadmin.site.register(views.CommAdminView, GlobalSetting)


class AlertItemsAdmin(object):
    list_display = ('name', 'desc', 'has_alert', 'deal_people', 'status', 'create_date','update_date')
    list_filter = ('name', 'desc', 'has_alert', 'deal_people', 'status', 'create_date', 'update_date')
    search_fields = ('name', 'desc', 'has_alert', 'deal_people', 'status')


xadmin.site.register(AlertItems, AlertItemsAdmin)
