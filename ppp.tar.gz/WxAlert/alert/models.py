# _*_ coding:utf-8 _*_

from __future__ import unicode_literals
from datetime import datetime
from django.db import models


# Create your models here.

# class User(models.Model):
#     username = models.CharField(max_length=20, default=u'帅哥', verbose_name=u'用户名')
#
#     email = models.EmailField(default='abcdefg@creditease.cn', verbose_name=u'邮箱')
#     mobile = models.CharField(default=u'11111111111', max_length=11)



class AlertItems(models.Model):
    status_choices = (
        (0, u'未处理'),
        (1, u'处理中'),
        (2, u'处理完毕'),
        (3, u''),
    )
    
    has_alert_choices = (
        (0, 'NO'),
        (1, 'YES'),
    )

    name = models.CharField(max_length=100, verbose_name=u"报警项")
    deal_people = models.CharField(max_length=20, default=u'未指派', verbose_name=u'处理人')
    has_alert = models.IntegerField(default=0, choices=has_alert_choices, verbose_name=u'微信消息成功发送')
    desc = models.TextField(verbose_name=u'异常描述')
    status = models.IntegerField(default=0, choices=status_choices, verbose_name=u'异常处理进度')
    create_date = models.DateTimeField(auto_now_add=True, verbose_name=u'异常上报时间')
    update_date = models.DateTimeField(auto_now=True, verbose_name=u'变更时间')

    class Meta:
        verbose_name = u"报警列表"
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.name