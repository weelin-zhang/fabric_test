# _*_ coding:utf-8 _*_

__author__ = 'weelin'
__date__ = '17/8/14下午10:27'

import os
import json
import sys
import time
import requests
from  WxAlert.celery import app

callback_url = '192.168.0.107'

access_token_path = os.path.join('utils', 'access_token')
# for 企业号
CORP_ID = 'ww0acf6b344a7dd7f4'
CORP_SECRET = 'IsLRca0dzd6w_-lD7VbIdmvCYtLVpzVLBL7HCr2Lw1Y'
AGENT_ID = '1000002'


def get_access_token_from_file():
    try:
        with open(access_token_path, 'r+') as f:
            current_access_token = f.read()
            print('get success %s' % current_access_token)
            return current_access_token
    except Exception as e:
        print(e)
        return None


def update_access_token():
    get_token_url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (CORP_ID, CORP_SECRET)
    # print(get_token_url)
    resp = requests.get(get_token_url)
    resp_json = resp.json()
    access_tk = resp_json['access_token']
    print(access_tk)
    resp.close()
    with open(access_token_path, 'w+') as f:
        f.write(access_tk)


# snedMessage

@app.task
def send_msg(alert_id, message, to_user='@all'):
    alert_msg = '''
==>Alert_item_id: {0}
==>detail: {1}
==>capture_url: {2}'''.format(alert_id, message, 'http://192.168.0.107:8000/alert/capture_url/{0}/'.format(alert_id))
    send_loop = True
    access_tk = get_access_token_from_file()
    if not access_tk:
        update_access_token()
        access_tk = get_access_token_from_file()
    while send_loop:
        try:
            send_message_url = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s' % access_tk
            message_params = {
                "touser": to_user,
                "msgtype": "text",
                "agentid": AGENT_ID,
                "text": {
                    "content": alert_msg
                },
                "safe": 0
            }
            resp = requests.post(send_message_url, data=json.dumps(message_params))
            #print('post success %s ' % resp.text)
            request_json = resp.json()
            errmsg = request_json['errmsg']
            if errmsg != 'ok':
                # 告警失败
                pass
            send_loop = False
            # 回应成功发送
            print  u'回应成功发送, 发送确认'
            requests.get('http://192.168.0.107:8000/alert/celery_verify/{0}/'.format(alert_id))

        except Exception as e:
            time.sleep(1)
            print(e)
